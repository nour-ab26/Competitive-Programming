#!/usr/bin/env python3

import os


os.system(f"git add . && git commit -m \"{input('[*] Commit: ')}\" ; git push")
